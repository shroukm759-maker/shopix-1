const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.get("/test", (req, res) => {
  res.json({ message: "Backend is working" });
});

let products = [
  {
    id: 1,
    name: "Product 1",
    price: 100,
    description: "First product",
    stock: 10
  }
];

app.get("/products", (req, res) => {
  res.json(products);
});

app.post("/products", (req, res) => {
  const product = {
    id: products.length + 1,
    ...req.body
  };
  products.push(product);
  res.status(201).json(product);
});

app.listen(3000, () => {
  console.log("Server running on port 3000");
});